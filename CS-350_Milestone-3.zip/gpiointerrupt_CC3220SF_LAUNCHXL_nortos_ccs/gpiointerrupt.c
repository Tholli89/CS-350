/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"

#include <ti/drivers/Timer.h>

/* Setting TimerFlag to 0 (lowered timer flag) */
volatile unsigned char TimerFlag = 0;

/* When called the function will raise the TimerFlag */
void timerCallback(Timer_Handle myHandle, int_fast16_t status)
{
    TimerFlag = 1;
}


void initTimer(void)
{
    Timer_Handle timer0;
    Timer_Params params;
    Timer_init();
    Timer_Params_init(&params);

    /* Changed the period to 500000 */
    params.period = 500000;
    params.periodUnits = Timer_PERIOD_US;
    params.timerMode = Timer_CONTINUOUS_CALLBACK;
    params.timerCallback = timerCallback;

    timer0 = Timer_open(CONFIG_TIMER_0, &params);

    if (timer0 == NULL) {
         /* Failed to initialized timer */
         while (1) {}
    }
    if (Timer_start(timer0) == Timer_STATUS_ERROR) {
         /* Failed to start timer */
         while (1) {}
    }
}

/* State Machine states */
enum SM_STATES {
    SM_Start,
    SM_S1,
    SM_O,
    SM_S2,
    SM_K,
    SM_MsgChk,

} SM_STATE;

/* initializing the ButtonPress variable to 0 (No button press has occurred) */
unsigned char ButtonPress = 0;

/* setting the Message value to 0 (SOS = 0, OK = 1) */
unsigned char Msg = 0;

void MorseCode_Tick(){
    unsigned char i;
    switch(SM_STATE) {

        /* initializer for starting or resetting the states execution
         * sets i to 0 and switches the state to S1 */
        case SM_Start:
            i = 0;
            SM_STATE = SM_S1;
            break;

        /* Will change the state after 8 iterations (8 * 500ms)
         * performs morse code for the first letter S */
        case SM_S1:
            if (!(i < 8)){
                i = 0;
                SM_STATE = SM_O;
            }
            break;

        /* Will change the state after 14 iterations (14 * 500ms)
         * performs morse code for the letter O */
        case SM_O:
            if (!(i <14)){
                i = 0;
                if (Msg){
                    SM_STATE = SM_K;
                }
                else{
                    SM_STATE = SM_S2;
                }
            }
            break;

        /* Will change the state after 5 iterations (5 * 500ms)
         * performs morse code for the second letter S */
        case SM_S2:
            if (!(i <5)){
                i = 0;
                SM_STATE = SM_MsgChk;
            }
            break;

        /* Will change the state after 9 iterations (9 * 500ms)
         * performs morse code for the letter K */
        case SM_K:
            if (!(i <9)){
                i = 0;
                SM_STATE = SM_MsgChk;
            }
            break;

        /* Will change the state after 7 iterations (7 * 500ms)
         * performs a check to verify which message to display (true = OK or false = SOS)
         * also acts as a pause between words for 3500ms */
        case SM_MsgChk:
            if (!(i < 7)){
                i = 0;
                if (Msg){
                    SM_STATE = SM_O;
                }
                else {
                    SM_STATE = SM_S1;
                }
            }
            break;

        /* Default case that resets execution if anything goes wrong */
        default:
            SM_STATE = SM_Start;
            break;
       }

    switch(SM_STATE){

         /* Start case has no functionality */
        case SM_Start:
            break;

        /* S1 case turns the red led on when i = 0, 2 , and 4
         * and off when i = 1, 3, 5, 6, and 7 */
        case SM_S1:
            if (i == 0 || i == 2 || i ==4){
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            }
            else {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            }
            i++;
            break;

        /* O case turns the green led on when i = 0, 1, 2, 4, 5, 6, 8, 9, and 10
         * and off when i = 3, 7, 11, 12, and 13 */
        case SM_O:
            if ((i < 3) || (i > 3 && i < 7) || (i > 7 && i < 11)) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            } else {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            }
            i++;
            break;

        /* S2 case turns the red led on when i = 0, 2, and 4
         * and off when i = 1 and 3 */
        case SM_S2:
            if (i == 0 || i == 2 || i == 4) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            } else {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            }
            i++;
            break;

        /* K case turns the green led on when i = 0, 1, 2, 6, 7, and 8
         * and off when i = 3, 4, and 5
         * K case also turns the red led on when i = 4
         * and off when i = 0, 1, 2, 3, 5, 6, 7, and 8*/
        case SM_K:
            if (i < 3 || i > 5) {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);
            } else {
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            }
            if (i == 4) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
            } else {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
            }
            i++;
            break;

         /* MsgChk case turns both the red and green LEDs off
          * then checks to see if a button press occurred
          * if one has occurred then the message is switched
          * and button click is set back to false */
        case SM_MsgChk:
            if (i == 0) {
                GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
                GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);
            } else if (i == 6) {
                /* If a button was pressed, switch the message and reset ButtonClick */
                if (ButtonPress) {
                    Msg = !Msg;
                    ButtonPress = 0;
                }
            }
            i++;
            break;

        /* Default case has no functionality */
        default:
            break;
    }
}

/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index)
{
    /* changes button press to true */
    ButtonPress = 1;

}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index)
{
    /* changes button press to true */
    ButtonPress = 1;

}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0)
{
    /* Call driver init functions */
    GPIO_init();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_LED_1, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);


    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Turn on user LED */
        GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_ON);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);

        /* Enable interrupts */
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }

    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    GPIO_write(CONFIG_GPIO_LED_1, CONFIG_GPIO_LED_OFF);

    SM_STATE = SM_Start;

    initTimer();
    while(1){
        MorseCode_Tick();
        while(!TimerFlag){}
        TimerFlag = 0;
    }

}
